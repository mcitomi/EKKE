﻿using System;
namespace konyvespolc
{
    class Book
    {
        private static int ID = 1; //A static mit is jelent?

        private int id;
        public int Id
        {
            get { return id; }
            private set
            {
                if (value < 1)
                    throw new Exception("The Id cannot be equals or less than 1!");
                id = value;
            }
        }

        private string _author; //első betű nagxbetűsnek kell lennie!!!!!!
        public string Author
        {
            get
            {
               return _author;
            }
            set
            {
                if (value.Length < 3 || value.Length > 20)
                    this._author = value.Substring(0, 20);
                    //throw new ArgumentException("A név hosszának 3 és 20 közöttinek kell lennie!");
                var reszek = value.Split(' ');
                //Kimaradt rész. Az első betűk nagybetűk, legalább 2 karakter 
                this._author = value;
            }
        }
        private string _title;
        public string Title
        {
            get
            {
                return this._title;
            }
            set
            {
                if (value.Length < 3 || value.Length > 50)
                    throw new ArgumentException("A cím hosszának 3 és 50 közöttinek kell lennie!");
                this._title = value;
            }
        }
        private DateTime _publishDate;
        public DateTime PublishDate
        {
            get
            {
                //kimaradt
            }
            set
            {
                //kimaradt
            }
        }
        private int _price;
        public int Price
        {
            get
            {
                return this._price;
            }
            set
            {
                //Kimaradt
            }
        }
        // public ..... genre_enum deklarálása;
        public bool isEbook = false;
        private bool _isSetPrice;
        public bool isSetPrice
        {
            get
            {
                return this._isSetPrice;
            }
        }

        // Kell egy priavate Book konstruktor, param nélkül
        //Konstruktorok megírása!!! 3+1

        public Book Clone
        {
            get
            {
                //return new Book(this.author, this.title, 
                //    this.price, this.genre); //Ez működik vajon?  Egyébként jobb, ha a Clone az Clone(). :-)
                Book clone = new Book();
                return clone;
            }
        }

        public override string ToString()
        {
            return $"Book[" +
                $"author='{Author}'," +
                $"title='{Title}'," +
                $"price='{(isSetPrice ? Price.ToString() + " HUF" : "N/A")}'," +
                $"genre='{genre}'," +
                $"ebook='{(isEbook ? "yes" : "no")}'" +
                $"]";
        }
        public override int GetHashCode()
        {
            return 1; //Mikor azonos két könyv?
        }
        public override bool Equals(object obj)
        {
            //Ezt ír meg kell írni, gyakorolják!
            return true;
        }
    }
}
