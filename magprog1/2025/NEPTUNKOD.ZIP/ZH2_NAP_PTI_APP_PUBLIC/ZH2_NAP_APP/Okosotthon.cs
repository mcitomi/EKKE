﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZH2_NAP_APP
{
    internal class Okosotthon
    {
        private Okosotthon() { }
        public Okosotthon(List<string> okosFunkciok) 
            : base(/**/)
        {
            foreach (string okosfunkcio in okosFunkciok)
            {
                this.okosFunkciok.Add((OkosFunkcio)Enum.Parse(typeof(OkosFunkcio), okosfunkcio));
            }
        }

        private List<OkosFunkcio> okosFunkciok = new List<OkosFunkcio>();
    }
}
