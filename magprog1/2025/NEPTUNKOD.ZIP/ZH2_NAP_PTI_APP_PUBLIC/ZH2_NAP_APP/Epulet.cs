﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZH2_NAP_APP
{
    internal class Epulet
    {
        protected Epulet() { }
        protected Epulet(int terulet, int szobak, EpitoCeg epitoCeg, EpuletTipus epuletTipus)
        {
            Terulet = terulet;
            Szobak = szobak;
            EpitoCeg = epitoCeg;
            EpuletTipus = epuletTipus;
        }

        public int Terulet { get; set; }
        public int Szobak { get; set; }
        public EpitoCeg EpitoCeg { get; set; }
        public EpuletTipus EpuletTipus { get; private set; }
    }
}
